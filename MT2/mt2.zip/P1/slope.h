// Return index of the first row that is not a slope, otherwise: -1
int find_nonslope_row(int array[6][6]);
int read_array(char* filename, int array[6][6]);

