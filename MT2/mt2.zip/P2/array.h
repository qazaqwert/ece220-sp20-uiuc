#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const static size_t n = 5;
void print_matirx(int arr[][n]);
void init_1st_row(int arr[][n]);
void init_1st_col(int arr[][n]);
void build_matrix_max(int arr[][n]);
